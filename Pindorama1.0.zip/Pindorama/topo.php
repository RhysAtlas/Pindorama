<style>
  body{
    background-color: 
    }
    .topo{
      HEIGHT: 150px; 
      WIDTH: 1366px;
      LEFT: 0px;
      POSITION: absolute; TOP: 0px;
      background-color: #FFEBCD;
    }
    .logo{
      LEFT: 630px;
      POSITION: absolute; TOP: 50px;
    }
    </style>

<div class="topo">
  <div class="logo"><h1>Logo</h1></div>
</div>