<?php
//conexao com servidor: IP do usuario e senha
$conn= mysqli_connect("localhost", "root", "unipe");

//teste se a variavel $conn recebe dados do servidor
if($conn){
    echo "Conexão com servidor vem sucedida!";
}

//selecionar banco de dados
$bd= mysqli_select_db($conn, "aula1bd");
?>