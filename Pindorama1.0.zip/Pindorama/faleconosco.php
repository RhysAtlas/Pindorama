<div style="background-color: #FDF5E6; HEIGHT: 210px; LEFT: 0px; POSITION: absolute; TOP:  271px; WIDTH: 1349px">
  <h2>FALE CONOSCO</h2>
  <p>Telefone: 83 99887744</p>
  <p>E-mail: ads2023@unipe.edu.br</p>
  <form action="?pg=sucesso" method="post">
    <label>Nome:</label>
    <input type="text" name="nome"/>
    <label>E-mail:</label>
    <input type="text" name="email"/>
    <label>Assunto:</label>
    <select name="assunto">
      <option value="Sugestão">Sugestão</option>
      <option value="Dúvida">Dúvida</option>
      <option value="Reclamação">Reclamação</option>
    </select>
    <label>Mensagem:</label>
    <textarea name="mensagem"></textarea>
    <input type="submit" value="Enviar"/>
  </form>
</div>