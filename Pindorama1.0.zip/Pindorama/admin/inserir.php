<h1>Cadastro</h1>
<form action="inserirbd.php" method="Post">
    <label>Nome da página</label>
    <input type="text"name="titulo"><br>
    <label>Conteudo</label>
    <input type="text"name="texto"><br>
    <label>Texto</label>
    <input type="submit" value="Cadastrar">
</form>