<h1>Login</h1>
<form action="login.php" method="Post">
    <label>Login</label>
    <input type="text"name="logar"><br>
    <label>Senha</label>
    <input type="text"name="senha"><br>
    <input type="submit" value="Logar">
</form>