<h1>Cadastro</h1>
<form action="inserirbd.php" method="Post">
    <label>Nome</label>
    <input type="text"name="nome"><br>
    <label>Email</label>
    <input type="text"name="email"><br>
    <label>Senha</label>
    <input type="text"name="passwor"><br>
    <input type="submit" value="Cadastrar">
</form>