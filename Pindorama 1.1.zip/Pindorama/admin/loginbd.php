<?php
include_once("../config.inc.php");

$titulo= $_REQUEST['logar'];
$texto=$_REQUEST['senha'];

$sql="INSERT INTO aula1 (logar,senha)
    VALUES ('$logar', '$senha')";

$login= mysqli_query($conn, $sql);

    if($login){
        echo "Login realizado com sucesso.";
    }
    else{
        echo "Login não realizado. Houve algum problema.";
    }
?>