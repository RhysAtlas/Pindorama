<?php
include_once("../config.inc.php");

$nome= $_REQUEST['nome'];
$email=$_REQUEST['email'];
$senha=$_REQUEST['password'];

$sql="INSERT INTO usuarios (nome,email,passwor)
    VALUES ('$nome', '$email','passwor')";

$inserir= mysqli_query($conn, $sql);

    if($inserir){
        echo "Cadastro realizado com sucesso.";
    }
    else{
        echo "Cadastro não realizado. Houve algum problema.";
    }
?>