
</div>
  <div style="background-color:#FDF5E6; HEIGHT: 70px; LEFT: 0px; POSITION: absolute; TOP: 581px; WIDTH: 1349px">
    <div style="POSITION: absolute; LEFT: 480px">
    <h2>RODAPÉ DO SITE</h2>
  </div>
</div>