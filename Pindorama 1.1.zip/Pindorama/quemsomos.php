<div style="background-color: #FDF5E6; HEIGHT: 210px; LEFT: 0px; POSITION: absolute; TOP:  271px; WIDTH: 1349px">
  <h2>QUEM SOMOS</h2>
  <p>Somos alunos do curso de ADS na UNIPE...</p>
</div>