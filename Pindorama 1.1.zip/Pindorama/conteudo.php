<style>
.s_cursos{
display: flex;
}
.curso{
  border: 1px solid #000;
  padding:5px;
  background-color: #eee;
  margin: 10px;
  HEIGHT: 250px;
  WIDTH: 350px;
  LEFT: 200px;
  POSITION: absolute; TOP: 250px;
}
.cursoo{
  border: 1px solid #000;
  padding:5px;
  margin: 10px;
  HEIGHT: 250px;
  WIDTH: 350px;
  LEFT: 800px;
  POSITION: absolute; TOP: 250px;
}
</style>

<div style="HEIGHT: 100px; LEFT: 1060px; POSITION: absolute; TOP:  120px; WIDTH: 300px"><button><a href="admin/login.php">Login</a></button></div>
<div style="HEIGHT: 100px; LEFT: 1120px; POSITION: absolute; TOP:  120px; WIDTH: 300px"><button><a href="admin/inserir.php">Cadastrar</a></button></div>


  <div class="s_cursos">
    <a href="quemsomos.php"><div class="curso"><h2>Grupo: GTA V</h2><img src="fotoo/gta v.jpg" alt=""></div></a>
    <a href="faleconosco.php"><div class="cursoo"><h2>Grupo: Minecraft</h2><img src="fotoo/minecraft.jpg"style="HEIGHT: 150px; WIDTH: 300px;"></div></a>
  </div>
